document.addEventListener('DOMContentLoaded', function() {
    const signupForm = document.getElementById('signupForm');
    const usernameInput = document.getElementById('username');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm-password');
    const errorMessage = document.getElementById('error-message');
    const termsCheckbox = document.getElementById('terms');
    const togglePassword = document.querySelector('.toggle-password');
    const strengthProgress = document.querySelector('.strength-progress');
    const strengthText = document.querySelector('.strength-text');
    const signupButton = document.querySelector('.signup-btn');
    
    // Password requirement checks
    const lengthCheck = document.getElementById('length-check');
    const uppercaseCheck = document.getElementById('uppercase-check');
    const numberCheck = document.getElementById('number-check');
    const specialCheck = document.getElementById('special-check');
    
    // Toggle password visibility
    togglePassword.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });
    
    // Password strength meter
    passwordInput.addEventListener('input', function() {
        const password = this.value;
        updatePasswordStrength(password);
        updateRequirementChecks(password);
    });
    
    function updatePasswordStrength(password) {
        let strength = 0;
        
        if (password.length >= 8) strength += 25;
        if (/[A-Z]/.test(password)) strength += 25;
        if (/[0-9]/.test(password)) strength += 25;
        if (/[!@#$%^&*]/.test(password)) strength += 25;
        
        strengthProgress.style.width = strength + '%';
        
        if (strength <= 25) {
            strengthProgress.style.backgroundColor = '#e74c3c';
            strengthText.textContent = 'Weak';
        } else if (strength <= 50) {
            strengthProgress.style.backgroundColor = '#f39c12';
            strengthText.textContent = 'Fair';
        } else if (strength <= 75) {
            strengthProgress.style.backgroundColor = '#3498db';
            strengthText.textContent = 'Good';
        } else {
            strengthProgress.style.backgroundColor = '#2ecc71';
            strengthText.textContent = 'Strong';
        }
    }
    
    function updateRequirementChecks(password) {
        // Check for length
        if (password.length >= 8) {
            lengthCheck.classList.add('valid');
        } else {
            lengthCheck.classList.remove('valid');
        }
        
        // Check for uppercase
        if (/[A-Z]/.test(password)) {
            uppercaseCheck.classList.add('valid');
        } else {
            uppercaseCheck.classList.remove('valid');
        }
        
        // Check for number
        if (/[0-9]/.test(password)) {
            numberCheck.classList.add('valid');
        } else {
            numberCheck.classList.remove('valid');
        }
        
        // Check for special character
        if (/[!@#$%^&*]/.test(password)) {
            specialCheck.classList.add('valid');
        } else {
            specialCheck.classList.remove('valid');
        }
    }
    
    // Form validation
    signupForm.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const username = usernameInput.value.trim();
        const email = emailInput.value.trim();
        const password = passwordInput.value;
        const confirmPassword = confirmPasswordInput.value;
        
        // Clear previous error messages
        clearError();
        
        // Validate username
        if (!username) {
            showError('Please enter a username');
            return;
        }
        
        // Validate email format
        if (!isValidEmail(email)) {
            showError('Please enter a valid email address');
            return;
        }
        
        // Validate email domain
        if (!email.endsWith('@gmail.com')) {
            showError('Email must end with @gmail.com');
            return;
        }
        
        // Validate password
        const passwordRequirements = /^(?=.*[A-Z])(?=.*[!@#$%^&*])(?=.*\d).{8,}$/;
        if (!passwordRequirements.test(password)) {
            showError('Password must meet all requirements');
            return;
        }
        
        // Validate confirm password
        if (password !== confirmPassword) {
            showError('Passwords do not match');
            return;
        }
        
        // Validate terms agreement
        if (!termsCheckbox.checked) {
            showError('You must agree to the Terms of Service');
            return;
        }
        
        // Show loading state
        signupButton.textContent = 'Creating Account...';
        signupButton.disabled = true;
        
        // Simulate API call with setTimeout
        setTimeout(function() {
            // For demonstration - in a real app, you would make an API call here
            console.log('Account created successfully');
            console.log('Username:', username);
            console.log('Email:', email);
            console.log('Password:', password);
            
            // Redirect to success page or login page
            alert('Account created successfully! Redirecting to login page...');
            window.location.href = 'login.html';
        }, 1500);
    });
    
    // Helper functions
    function isValidEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }
    
    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.classList.add('shake');
        setTimeout(() => {
            errorMessage.classList.remove('shake');
        }, 500);
    }
    
    function clearError() {
        errorMessage.textContent = '';
    }
    
    // Add animation to input fields
    const inputFields = document.querySelectorAll('.input-field');
    inputFields.forEach(field => {
        const input = field.querySelector('input');
        
        input.addEventListener('focus', () => {
            field.style.borderColor = '#3498db';
        });
        
        input.addEventListener('blur', () => {
            field.style.borderColor = input.value ? '#3498db' : '#ddd';
        });
    });
});