
    const loginForm = document.getElementById('loginForm');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const errorMessage = document.getElementById('error-message');
    const togglePassword = document.querySelector('.toggle-password');
    
    // Toggle password visibility
    togglePassword.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });
    
    // Login form submission
    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();
        
        // Basic validation
        if (!username || !password) {
            showError('Please enter both username and password');
            return;
        }
        
        // Clear any previous error messages
        clearError();
        
        // Show loading state
        const button = this.querySelector('button');
        const originalText = button.textContent;
        button.textContent = 'Logging in...';
        button.disabled = true;
        
        // Simulate API call with setTimeout
        setTimeout(function() {
            // For demonstration only - in a real app, you would make an API call here
            if (username === 'admin' && password === 'password') {
                // Successful login
                localStorage.setItem('isLoggedIn', 'true');
                window.location.href = 'dashboard.html';
            } else {
                // Failed login
                showError('Invalid username or password');
                button.textContent = originalText;
                button.disabled = false;
            }
        }, 1000);
    });
    
    // Helper functions
    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.style.opacity = '1';
        
        // Add shake animation
        errorMessage.classList.add('shake');
        setTimeout(() => {
            errorMessage.classList.remove('shake');
        }, 500);
    }
    
    function clearError() {
        errorMessage.textContent = '';
        errorMessage.style.opacity = '0';
    }
    
    // Add some simple animations for input fields
    const inputFields = document.querySelectorAll('.input-field');
    inputFields.forEach(field => {
        const input = field.querySelector('input');
        
        input.addEventListener('focus', () => {
            field.style.borderColor = '#3498db';
        });
        
        input.addEventListener('blur', () => {
            field.style.borderColor = input.value ? '#3498db' : '#ddd';
        });
    });
    
    