document.addEventListener('DOMContentLoaded', function() {
    // Get form elements
    const emailForm = document.getElementById('emailForm');
    const verificationForm = document.getElementById('verificationForm');
    const newPasswordForm = document.getElementById('newPasswordForm');
    
    // Get step containers
    const stepEmail = document.getElementById('step-email');
    const stepVerification = document.getElementById('step-verification');
    const stepNewPassword = document.getElementById('step-new-password');
    const stepSuccess = document.getElementById('step-success');
    
    // Get progress indicators
    const progress1 = document.getElementById('progress-1');
    const progress2 = document.getElementById('progress-2');
    const progress3 = document.getElementById('progress-3');
    
    // Get error message elements
    const emailError = document.getElementById('email-error');
    const verificationError = document.getElementById('verification-error');
    const passwordError = document.getElementById('password-error');
    
    // Get password elements
    const newPasswordInput = document.getElementById('new-password');
    const confirmNewPasswordInput = document.getElementById('confirm-new-password');
    const togglePassword = document.querySelector('.toggle-password');
    const strengthProgress = document.querySelector('.strength-progress');
    const strengthText = document.querySelector('.strength-text');
    
    // Get verification code inputs
    const verificationInputs = document.querySelectorAll('.verification-input');
    
    // Get timer elements
    const timerDisplay = document.getElementById('timer');
    const resendCodeBtn = document.getElementById('resend-code');
    
    // Password requirement checks
    const lengthCheck = document.getElementById('length-check');
    const uppercaseCheck = document.getElementById('uppercase-check');
    const numberCheck = document.getElementById('number-check');
    const specialCheck = document.getElementById('special-check');
    
    // Toggle password visibility
    togglePassword.addEventListener('click', function() {
        const type = newPasswordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        newPasswordInput.setAttribute('type', type);
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });
    
    // Handle verification code input
    verificationInputs.forEach((input, index) => {
        // Auto focus next input when a digit is entered
        input.addEventListener('input', function() {
            if (this.value.length === 1) {
                if (index < verificationInputs.length - 1) {
                    verificationInputs[index + 1].focus();
                }
            }
        });
        
        // Handle backspace
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Backspace' && index > 0 && !this.value) {
                verificationInputs[index - 1].focus();
            }
        });
        
        // Allow only digits
        input.addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    });
    
    // Start timer for verification code expiration
    let timeLeft = 300; // 5 minutes in seconds
    
    function startTimer() {
        const timerInterval = setInterval(function() {
            timeLeft--;
            
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            
            timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            
            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                resendCodeBtn.disabled = false;
                verificationError.textContent = 'Verification code has expired. Please request a new one.';
            }
        }, 1000);
    }
    
    // Set up resend code button
    resendCodeBtn.addEventListener('click', function() {
        // Reset the timer
        timeLeft = 300;
        timerDisplay.textContent = '05:00';
        
        // Disable the resend button again
        this.disabled = true;
        
        // Clear any error messages
        verificationError.textContent = '';
        
        // Clear the input fields
        verificationInputs.forEach(input => {
            input.value = '';
        });
        
        // Focus the first input field
        verificationInputs[0].focus();
        
        // Show a success message (simulated)
        alert('A new verification code has been sent to your email address.');
        
        // Restart the timer
        startTimer();
    });
    
    // Password strength meter
    newPasswordInput.addEventListener('input', function() {
        const password = this.value;
        updatePasswordStrength(password);
        updateRequirementChecks(password);
    });
    
    function updatePasswordStrength(password) {
        let strength = 0;
        
        if (password.length >= 8) strength += 25;
        if (/[A-Z]/.test(password)) strength += 25;
        if (/[0-9]/.test(password)) strength += 25;
        if (/[!@#$%^&*]/.test(password)) strength += 25;
        
        strengthProgress.style.width = strength + '%';
        
        if (strength <= 25) {
            strengthProgress.style.backgroundColor = '#e74c3c';
            strengthText.textContent = 'Weak';
        } else if (strength <= 50) {
            strengthProgress.style.backgroundColor = '#f39c12';
            strengthText.textContent = 'Fair';
        } else if (strength <= 75) {
            strengthProgress.style.backgroundColor = '#3498db';
            strengthText.textContent = 'Good';
        } else {
            strengthProgress.style.backgroundColor = '#2ecc71';
            strengthText.textContent = 'Strong';
        }
    }
    
    function updateRequirementChecks(password) {
        // Check for length
        if (password.length >= 8) {
            lengthCheck.classList.add('valid');
        } else {
            lengthCheck.classList.remove('valid');
        }
        
        // Check for uppercase
        if (/[A-Z]/.test(password)) {
            uppercaseCheck.classList.add('valid');
        } else {
            uppercaseCheck.classList.remove('valid');
        }
        
        // Check for number
        if (/[0-9]/.test(password)) {
            numberCheck.classList.add('valid');
        } else {
            numberCheck.classList.remove('valid');
        }
        
        // Check for special character
        if (/[!@#$%^&*]/.test(password)) {
            specialCheck.classList.add('valid');
        } else {
            specialCheck.classList.remove('valid');
        }
    }
    
    // Email form submission
    emailForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value.trim();
        
        // Validate email
        if (!email) {
            showError(emailError, 'Please enter your email address');
            return;
        }
        
        // Check if it's a valid email format
        if (!isValidEmail(email)) {
            showError(emailError, 'Please enter a valid email address');
            return;
        }
        
        // Check if email ends with @gmail.com
        if (!email.endsWith('@gmail.com')) {
            showError(emailError, 'Email must end with @gmail.com');
            return;
        }
        
        // Show loading state
        const button = this.querySelector('button');
        button.textContent = 'Sending...';
        button.disabled = true;
        
        // Simulate API call with setTimeout
        setTimeout(function() {
            // Move to verification step
            stepEmail.style.display = 'none';
            stepVerification.style.display = 'block';
            
            // Update progress indicators
            progress1.classList.add('completed');
            progress2.classList.add('active');
            
            // Start the verification code timer
            startTimer();
            
            // Focus the first verification input
            verificationInputs[0].focus();
        }, 1500);
    });
    
    // Verification form submission
    verificationForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get the verification code
        let code = '';
        let isComplete = true;
        
        verificationInputs.forEach(input => {
            if (!input.value) {
                isComplete = false;
            }
            code += input.value;
        });
        
        // Check if code is complete
        if (!isComplete) {
            showError(verificationError, 'Please enter the complete verification code');
            return;
        }
        
        // Simulate code verification (in a real app, you would verify the code with your backend)
        // For this example, we'll accept any 6-digit code
        if (code.length !== 6) {
            showError(verificationError, 'Verification code must be 6 digits');
            return;
        }
        
        // Show loading state
        const button = this.querySelector('button');
        button.textContent = 'Verifying...';
        button.disabled = true;
        
        // Simulate API call with setTimeout
        setTimeout(function() {
            // Move to new password step
            stepVerification.style.display = 'none';
            stepNewPassword.style.display = 'block';
            
            // Update progress indicators
            progress2.classList.add('completed');
            progress3.classList.add('active');
            
            // Reset button
            button.textContent = 'Verify Code';
            button.disabled = false;
        }, 1500);
    });
    
    // New password form submission
    newPasswordForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const newPassword = newPasswordInput.value;
        const confirmNewPassword = confirmNewPasswordInput.value;
        
        // Validate password
        const passwordRequirements = /^(?=.*[A-Z])(?=.*[!@#$%^&*])(?=.*\d).{8,}$/;
        if (!passwordRequirements.test(newPassword)) {
            showError(passwordError, 'Password must meet all requirements');
            return;
        }
        
        // Validate confirm password
        if (newPassword !== confirmNewPassword) {
            showError(passwordError, 'Passwords do not match');
            return;
        }
        
        // Show loading state
        const button = this.querySelector('button');
        button.textContent = 'Resetting...';
        button.disabled = true;
        
        // Simulate API call with setTimeout
        setTimeout(function() {
            // Move to success step
            stepNewPassword.style.display = 'none';
            stepSuccess.style.display = 'block';
            
            // Update progress indicators
            progress3.classList.add('completed');
        }, 1500);
    });
    
    // Helper functions
    function isValidEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }
    
    function showError(element, message) {
        element.textContent = message;
        element.classList.add('shake');
        setTimeout(() => {
            element.classList.remove('shake');
        }, 500);
    }
});